package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class TE
 */
@WebServlet("/TE")
public class TE extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		response.setContentType("text/html; charset=utf-8");
		PrintWriter out = response.getWriter();
		
		TagDAO tdao = new TagDAO();

		try {
			
			
			
			
			

			String action = request.getParameter("action");
			if(action != null) {
				if(action.equals("AllSignal")) {
					List<AllSignalDTO> list = tdao.AllSignalList();
					request.setAttribute("list", list);
				
					RequestDispatcher rd = request.getRequestDispatcher("AllSignal.jsp");
					rd.forward(request, response);
				}
			
				else if(action.equals("NomalSignal")) {
					List<NomalSignalDTO> nomallist = tdao.NomalSignalList();
					request.setAttribute("nomallist", nomallist);
				
					RequestDispatcher rd = request.getRequestDispatcher("NomalSignal.jsp");
					rd.forward(request, response);
				}
				
				else if(action.equals("CalculationSignal")) {
					List<CalculationSignalDTO> CalculationSignallist = tdao.CalculationSignallist();
					request.setAttribute("CalculationSignallist", CalculationSignallist);
				
					RequestDispatcher rd = request.getRequestDispatcher("CalculationSignal.jsp");
					rd.forward(request, response);
				}
				
				else if(action.equals("CountSignal")) {
					List<CountSignalDTO> CountSignallist = tdao.CountSignallist();
					request.setAttribute("CountSignallist", CountSignallist);
				
					RequestDispatcher rd = request.getRequestDispatcher("CountSignal.jsp");
					rd.forward(request, response);
				}
				
				else if(action.equals("NomalSignalAdd")) {
					String Signal = request.getParameter("Signal");
					String TagName = request.getParameter("TagName");
					String SigName = request.getParameter("SigName");
					String Description = request.getParameter("Description");
					String EquipmentName = request.getParameter("EquipmentName");
					String SigType = request.getParameter("SigType");
					String EngLow  = request.getParameter("EngLow");
					String EngHigh  = request.getParameter("EngHigh");
					String Unit  = request.getParameter("Unit");
					String StayTime  = request.getParameter("StayTime");
					String LL  = request.getParameter("LL");
					String L  = request.getParameter("L");
					String H  = request.getParameter("H");
					String HH  = request.getParameter("HH");
					String Alarm  = request.getParameter("Alarm");
					String DI = request.getParameter("DI");
					String SourceTagName  = request.getParameter("SourceTagName");
					String SignalBit  = request.getParameter("SignalBit");
					String DecimalPoint  = request.getParameter("DecimalPoint");
				
					tdao.NomalSignalAdd(Signal, TagName, SigName, Description, EquipmentName, SigType, EngLow, EngHigh, Unit, StayTime, LL, L, H, HH, Alarm,DI,SourceTagName, SignalBit, DecimalPoint );
					
					RequestDispatcher rd = request.getRequestDispatcher("NomalSignalAdd.jsp");
					rd.forward(request, response);
					
				}
				
				else if(action.equals("CalculationSignalAdd")) {
					String calctagName = request.getParameter("calctagName");
					String EquipmentName = request.getParameter("EquipmentName");
					String EngLow = request.getParameter("EngLow");
					String EngHigh = request.getParameter("EngHigh");
					String Unit = request.getParameter("Uint");
					String Description = request.getParameter("Description");
					String Calculation = request.getParameter("Calculation");
					String L = request.getParameter("L");
					String H = request.getParameter("H");
					String DecimalPoint = request.getParameter("DecimalPoint");
					String Alarm = request.getParameter("Alarm");
					String Signal = request.getParameter("Signal");
					
					tdao.CalculationSignalAdd(calctagName, EquipmentName, EngLow, EngHigh, Unit, Description, Calculation, L, H, DecimalPoint, Alarm, Signal);
					
					RequestDispatcher rd = request.getRequestDispatcher("CalculationSignalAdd.jsp");
					rd.forward(request, response);
				}
				
				else if(action.equals("update")) {
					String jsArray = request.getParameter("rowdata");


					if(jsArray != null) {
						System.out.println("����");
						
						System.out.println(jsArray);
						
						ArrayList<String> ndto =  (ArrayList<String>) tdao.jsArrayChange(jsArray);						
						

						for(int i = 0; i < ndto.size(); i++) {
							System.out.println(ndto.get(i));
						}
						
						if(ndto != null) {
							
							request.setAttribute("ndto", ndto);
							
							RequestDispatcher rd = request.getRequestDispatcher("SignalUpdate.jsp");
							rd.forward(request, response);
							
						}
					}
				}
				
				
				

		}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	
	}

	

}
