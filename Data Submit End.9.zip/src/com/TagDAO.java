package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;






public class TagDAO {
	
	
	private Connection conn;
	private Statement stmt;
	private ResultSet rs;
	
	String url = "jdbc:postgresql://localhost:5432/postgres";
    String user = "postgres";
    String password = "aktlapffh2";
	
	
	
	private Connection getConnection() throws SQLException{
		conn = DriverManager.getConnection(url, user, password);
		return conn;
	}
	
	
	private void quitDB() {
		try {
			if (rs != null)
				rs.close();
			if (stmt != null)
				stmt.close();
			if (conn != null)
				conn.close();
		} catch (Exception e) {
			e.getStackTrace();
		}
	}
	/*===========================================================================================*/
	
	
	
	/*==============================================seq�ʱ�ȭ=============================================*/
	public void DeleteAllData() throws SQLException {
		try {
			Class.forName("org.postgresql.Driver");
			stmt = getConnection().createStatement();
			String sql = "TRUNCATE TABLE AllSignal";
			stmt.executeUpdate(sql);
		
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (stmt != null)
				stmt.close();
			if (conn != null)
				conn.close();
		}
		
	}

	public void SequenceNumberReset() throws SQLException {
		try {
		Class.forName("org.postgresql.Driver");
		stmt = getConnection().createStatement(); // Ŀ�ؼ��� ����

		String sql = "ALTER SEQUENCE Seq_Signal RESTART WITH 1";
		stmt.executeUpdate(sql);
		
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (stmt != null)
				stmt.close();
			if (conn != null)
				conn.close();
		}
		
	}

	public void GetAllData1() throws SQLException {
		try {
		Class.forName("org.postgresql.Driver");
		stmt = getConnection().createStatement(); // Ŀ�ؼ��� ����
		String sql = "INSERT INTO AllSignal (signal, EquipmentName, tagname, signame, description, sigtype, englow, enghigh,\r\n" + 
				"unit, alarm, staytime, ll, l, h, hh, di)\r\n" + 
				"SELECT signal, EquipmentName, tagname, signame, description, sigtype, englow, enghigh,\r\n" + 
				"unit, alarm, staytime, ll, l, h, hh, di\r\n" + 
				"FROM NomalSignal";
		stmt.executeUpdate(sql);
		
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (stmt != null)
				stmt.close();
			if (conn != null)
				conn.close();
		}
		
	}
	public void GetAllData2() throws SQLException {
		try {
			Class.forName("org.postgresql.Driver");
			stmt = getConnection().createStatement();
			String sql = "INSERT INTO AllSignal (tagname, signal, EquipmentName, description, englow, enghigh,\r\n"
					+ "unit, alarm, l, h)\r\n"
					+ "SELECT (CalcTagName)AS tagname,signal, EquipmentName, description, englow, enghigh,\r\n"
					+ "unit, alarm, l, h\r\n"
					+ "FROM CalculationSignal";
			stmt.executeUpdate(sql);
			
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				if (stmt != null)
					stmt.close();
				if (conn != null)
					conn.close();
			}
		
	}
	public void GetAllData3() throws SQLException {
		try {
		Class.forName("org.postgresql.Driver");
		stmt = getConnection().createStatement();
		String sql = "INSERT INTO AllSignal (tagname, signal, EquipmentName, description, unit, alarm, l, h)\r\n"
				+ "SELECT (CountTagName)AS tagname, signal, EquipmentName, description, unit, alarm, l, h\r\n"
				+ "FROM CountSignal";
		stmt.executeUpdate(sql);
		
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (stmt != null)
				stmt.close();
			if (conn != null)
				conn.close();
		}
		
	}
	
	/*==============================================Allsignal list=============================================*/
	public List<AllSignalDTO> AllSignalList() throws ClassNotFoundException, SQLException {
		DeleteAllData();
		SequenceNumberReset();
		GetAllData1();
		GetAllData2();
		GetAllData3();
		
		String sql = "select * from AllSignal";
		
		List<AllSignalDTO> list = new ArrayList<AllSignalDTO>();
		
		try{
			Class.forName("org.postgresql.Driver");
			stmt = getConnection().createStatement();
			
			rs = stmt.executeQuery(sql);
			while(rs.next()) {
				AllSignalDTO allmember = new AllSignalDTO();
				allmember.setTagnumber(rs.getInt("TagNumber"));
				allmember.setSignal(rs.getString("Signal"));
				allmember.setEquipmentname(rs.getString("Equipmentname"));
				allmember.setTagname(rs.getString("TagName"));
				allmember.setSigname(rs.getString("SigName"));
				allmember.setDescription(rs.getString("Description"));
				allmember.setSigtype(rs.getString("SigType"));
				allmember.setEnglow(rs.getInt("EngLow"));
				allmember.setEnghigh(rs.getInt("EngHigh"));
				allmember.setUnit(rs.getString("Unit"));
				allmember.setAlarm(rs.getString("Alarm"));
				allmember.setStaytime(rs.getInt("StayTime"));
				allmember.setLl(rs.getInt("LL"));
				allmember.setL(rs.getInt("L"));
				allmember.setH(rs.getInt("H"));
				allmember.setHh(rs.getInt("HH"));
				allmember.setDi(rs.getInt("DI"));
				list.add(allmember);
			
			}
		}
			catch (Exception e) {
				e.printStackTrace();
			} finally {
				quitDB(); // DB ���� ���� / Connection ��ȯ
			}
			return list; // list ��ȯ
		}
	
	
	/*==============================================Nomalsignal list=============================================*/
	public List<NomalSignalDTO> NomalSignalList() throws ClassNotFoundException, SQLException {
		
		
		String sql = "select * from NomalSignal";
		
		List<NomalSignalDTO> nomallist = new ArrayList<NomalSignalDTO>();
		
		try{
			Class.forName("org.postgresql.Driver");
			stmt = getConnection().createStatement();
			
			rs = stmt.executeQuery(sql);
			while(rs.next()) {
				NomalSignalDTO nomalmember = new NomalSignalDTO();
				nomalmember.setTagnumber(rs.getInt("TagNumber"));
				nomalmember.setSignal(rs.getString("Signal"));
				nomalmember.setEquipmentname(rs.getString("Equipmentname"));
				nomalmember.setTagname(rs.getString("TagName"));
				nomalmember.setSigname(rs.getString("SigName"));
				nomalmember.setDescription(rs.getString("Description"));
				nomalmember.setSigtype(rs.getString("SigType"));
				nomalmember.setEnglow(rs.getInt("EngLow"));
				nomalmember.setEnghigh(rs.getInt("EngHigh"));
				nomalmember.setUnit(rs.getString("Unit"));
				nomalmember.setAlarm(rs.getString("Alarm"));
				nomalmember.setStaytime(rs.getInt("StayTime"));
				nomalmember.setLl(rs.getInt("LL"));
				nomalmember.setL(rs.getInt("L"));
				nomalmember.setH(rs.getInt("H"));
				nomalmember.setHh(rs.getInt("HH"));
				nomalmember.setDi(rs.getInt("DI"));
				nomalmember.setSourcetagname(rs.getString("sourceTagName"));
				nomalmember.setSignalbit(rs.getInt("signalBit"));
				nomalmember.setDecimalpoint(rs.getInt("decimalPoint"));
				
				nomallist.add(nomalmember);
			
			}
		}
			catch (Exception e) {
				e.printStackTrace();
			} finally {
				quitDB(); // DB ���� ���� / Connection ��ȯ
			}
			return nomallist; // list ��ȯ
		}
	
	
	
	/*==============================================CalculationSignal list=============================================*/
	public List<CalculationSignalDTO> CalculationSignallist() throws ClassNotFoundException, SQLException {
		
		
		String sql = "select * from CalculationSignal";
		
		List<CalculationSignalDTO> Calculationlist = new ArrayList<CalculationSignalDTO>();
		
		try{
			Class.forName("org.postgresql.Driver");
			stmt = getConnection().createStatement();
			
			rs = stmt.executeQuery(sql);
			while(rs.next()) {
				CalculationSignalDTO calculationmember = new CalculationSignalDTO();
				calculationmember.setTagnumber(rs.getInt("TagNumber"));
				calculationmember.setSignal(rs.getString("Signal"));
				calculationmember.setEquipmentname(rs.getString("Equipmentname"));
				calculationmember.setCalctagname(rs.getString("calcTagName"));
				calculationmember.setDescription(rs.getString("Description"));
				calculationmember.setCalculation(rs.getString("calculation"));
				calculationmember.setEnglow(rs.getInt("EngLow"));
				calculationmember.setEnghigh(rs.getInt("EngHigh"));
				calculationmember.setUnit(rs.getString("Unit"));
				calculationmember.setAlarm(rs.getString("Alarm"));
				calculationmember.setL(rs.getInt("L"));
				calculationmember.setH(rs.getInt("H"));
				calculationmember.setDecimalpoint(rs.getInt("decimalPoint"));
				
				Calculationlist.add(calculationmember);
			
			}
		}
			catch (Exception e) {
				e.printStackTrace();
			} finally {
				quitDB(); // DB ���� ���� / Connection ��ȯ
			}
			return Calculationlist; // list ��ȯ
		}
	
	
	
	
	/*==============================================Countsignal list=============================================*/
	public List<CountSignalDTO> CountSignallist() throws ClassNotFoundException, SQLException {
		
		
		String sql = "select * from CountSignal";
		
		List<CountSignalDTO> countllist = new ArrayList<CountSignalDTO>();
		
		try{
			Class.forName("org.postgresql.Driver");
			stmt = getConnection().createStatement();
			
			rs = stmt.executeQuery(sql);
			while(rs.next()) {
				CountSignalDTO countmember = new CountSignalDTO();
				countmember.setTagnumber(rs.getInt("TagNumber"));
				countmember.setSignal(rs.getString("Signal"));
				countmember.setEquipmentname(rs.getString("Equipmentname"));
				countmember.setCounttagname(rs.getString("countTagName"));
				countmember.setDescription(rs.getString("Description"));
				countmember.setL(rs.getInt("L"));
				countmember.setH(rs.getInt("H"));
				countmember.setAlarm(rs.getString("Alarm"));
				countmember.setUnit(rs.getString("Unit"));
				countmember.setConditiontag1(rs.getString("ConditionTag1"));
				countmember.setCondition1(rs.getString("Condition1"));
				countmember.setValue1(rs.getInt("value1"));
				countmember.setConditiontag2(rs.getString("ConditionTag2"));
				countmember.setCondition2(rs.getString("Condition2"));
				countmember.setValue2(rs.getInt("value2"));
				countmember.setConditiontag3(rs.getString("ConditionTag3"));
				countmember.setCondition3(rs.getString("Condition3"));
				countmember.setValue3(rs.getInt("value3"));
				countmember.setConditiontag4(rs.getString("ConditionTag4"));
				countmember.setCondition4(rs.getString("Condition4"));
				countmember.setValue4(rs.getInt("value4"));
				countmember.setConditiontag5(rs.getString("ConditionTag5"));
				countmember.setCondition5(rs.getString("Condition5"));
				countmember.setValue5(rs.getInt("value5"));
				countmember.setDecimalpoint(rs.getInt("decimalPoint"));
				
				countllist.add(countmember);
			
			}
		}
			catch (Exception e) {
				e.printStackTrace();
			} finally {
				quitDB(); // DB ���� ���� / Connection ��ȯ
			}
			return countllist; // list ��ȯ
		}
	
	
	/*==============================================Nomalsignal Add=============================================*/
	public void NomalSignalAdd(String Signal, String TagName,String SigName,  String Description, String EquipmentName,
			String SigType, String EngLow, String EngHigh, String Unit, String StayTime,
			String LL, String L, String H, String HH, String Alarm, String DI, String SourceTagName, String SignalBit, String DecimalPoint) throws SQLException, ClassNotFoundException {
		
		if(Description == null) {
			Description ="''";
		}
		else if(Unit == null) {
			Unit = "''";
		}

		
		String sql = "insert into NomalSignal (Signal, TagName, SigName, Description, EquipmentName, SigType, EngLow, EngHigh, Unit, StayTime, LL, L, H, HH, Alarm,DI,SourceTagName,SignalBit, DecimalPoint  )"
				+ "VALUES('"+Signal+"','"+ TagName+"','"+SigName+"','"+Description+"','"+EquipmentName+"','"+SigType+"',"+EngLow+","+EngHigh+",'"+Unit+"',"+StayTime+","+LL+
				","+L+","+H+","+HH+",'"+Alarm+"',"+DI+",'"+SourceTagName+"',"+SignalBit+","+DecimalPoint+")";
		
		try {
			Class.forName("org.postgresql.Driver");
			stmt = getConnection().createStatement();
			stmt.executeUpdate(sql);
		}
		catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (stmt != null)
				stmt.close();
			if (conn != null)
				conn.close();
		}
	}
		
		/*==============================================CalculationSignal Add=============================================*/
		
		public void CalculationSignalAdd(String calctagName,String EquipmentName,String EngLow,String EngHigh,String Unit
				,String Description,String Calculation,String L,String H ,String DecimalPoint,String Alarm,String Signal) throws SQLException, ClassNotFoundException {
			
			if(Alarm == null) {
				Alarm="''";
			}

			
			String sql = "insert into CalculationSignal (Signal, EquipmentName, CalcTagName, Description, Calculation, EngLow, EngHigh, Unit, L, H, Alarm, DecimalPoint)"
					+ "VALUES('"+Signal+"','"+ EquipmentName+"','"+calctagName+"','"+Description+"','"+Calculation+"',"+EngLow+","+EngHigh+",'"+Unit+"',"+L+","+H+",'"+Alarm+"',"+DecimalPoint+")";
			
			try {
				Class.forName("org.postgresql.Driver");
				stmt = getConnection().createStatement();
				stmt.executeUpdate(sql);
			}
			catch (Exception e) {
				e.printStackTrace();
			} finally {
				if (stmt != null)
					stmt.close();
				if (conn != null)
					conn.close();
			}

		
	}
		
		
		
	
		/*==============================================CalculationSignal Add=============================================*/

		public List<String> jsArrayChange(String a) {
			
			String[] f = {"1"};
			f = a.split(",");
			final List<String> list = new ArrayList<String>();
			Collections.addAll(list, f);
			return list;

		}

}
