package com;

public class CountSignalDTO {
	private int tagnumber;
	private String signal;
	private String equipmentname;
	private String counttagname;
	private String description;
	private String alarm;
	private String unit;
	private int l;
	private int h;
	private int decimalpoint;
	private String conditiontag1;
	private String condition1;
	private int value1;
	private String conditiontag2;
	private String condition2;
	private int value2;
	private String conditiontag3;
	private String condition3;
	private int value3;
	private String conditiontag4;
	private String condition4;
	private int value4;
	private String conditiontag5;
	private String condition5;
	private int value5;
	
	
	
	
	
	public int getTagnumber() {
		return tagnumber;
	}
	public void setTagnumber(int tagnumber) {
		this.tagnumber = tagnumber;
	}
	public String getSignal() {
		return signal;
	}
	public void setSignal(String signal) {
		this.signal = signal;
	}
	public String getEquipmentname() {
		return equipmentname;
	}
	public void setEquipmentname(String equipmentname) {
		this.equipmentname = equipmentname;
	}

	public String getCounttagname() {
		return counttagname;
	}
	public void setCounttagname(String counttagname) {
		this.counttagname = counttagname;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getAlarm() {
		return alarm;
	}
	public void setAlarm(String alarm) {
		this.alarm = alarm;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public int getL() {
		return l;
	}
	public void setL(int l) {
		this.l = l;
	}
	public int getH() {
		return h;
	}
	public void setH(int h) {
		this.h = h;
	}
	public int getDecimalpoint() {
		return decimalpoint;
	}
	public void setDecimalpoint(int decimalpoint) {
		this.decimalpoint = decimalpoint;
	}
	public String getConditiontag1() {
		return conditiontag1;
	}
	public void setConditiontag1(String conditiontag1) {
		this.conditiontag1 = conditiontag1;
	}
	public String getCondition1() {
		return condition1;
	}
	public void setCondition1(String condition1) {
		this.condition1 = condition1;
	}
	public int getValue1() {
		return value1;
	}
	public void setValue1(int value1) {
		this.value1 = value1;
	}
	public String getConditiontag2() {
		return conditiontag2;
	}
	public void setConditiontag2(String conditiontag2) {
		this.conditiontag2 = conditiontag2;
	}
	public String getCondition2() {
		return condition2;
	}
	public void setCondition2(String condition2) {
		this.condition2 = condition2;
	}
	public int getValue2() {
		return value2;
	}
	public void setValue2(int value2) {
		this.value2 = value2;
	}
	public String getConditiontag3() {
		return conditiontag3;
	}
	public void setConditiontag3(String conditiontag3) {
		this.conditiontag3 = conditiontag3;
	}
	public String getCondition3() {
		return condition3;
	}
	public void setCondition3(String condition3) {
		this.condition3 = condition3;
	}
	public int getValue3() {
		return value3;
	}
	public void setValue3(int value3) {
		this.value3 = value3;
	}
	public String getConditiontag4() {
		return conditiontag4;
	}
	public void setConditiontag4(String conditiontag4) {
		this.conditiontag4 = conditiontag4;
	}
	public String getCondition4() {
		return condition4;
	}
	public void setCondition4(String condition4) {
		this.condition4 = condition4;
	}
	public int getValue4() {
		return value4;
	}
	public void setValue4(int value4) {
		this.value4 = value4;
	}
	public String getConditiontag5() {
		return conditiontag5;
	}
	public void setConditiontag5(String conditiontag5) {
		this.conditiontag5 = conditiontag5;
	}
	public String getCondition5() {
		return condition5;
	}
	public void setCondition5(String condition5) {
		this.condition5 = condition5;
	}
	public int getValue5() {
		return value5;
	}
	public void setValue5(int value5) {
		this.value5 = value5;
	}
	
	
	
	
	
}
